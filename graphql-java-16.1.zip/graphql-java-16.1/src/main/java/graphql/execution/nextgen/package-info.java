/**
 * WARNING: All code in this package is a work in progress for a new execution engine.
 * It is not really "wired up" and can't be really used and should not be used yet!
 */
package graphql.execution.nextgen;
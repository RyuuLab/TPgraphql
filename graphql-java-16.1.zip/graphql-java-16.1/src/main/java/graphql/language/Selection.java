package graphql.language;


import graphql.PublicApi;

@PublicApi
public interface Selection<T extends Selection> extends Node<T> {
}

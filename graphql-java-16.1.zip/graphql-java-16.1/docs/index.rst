Welcome to graphql-java
=======================

.. image:: https://avatars1.githubusercontent.com/u/14289921?s=200&v=4
    :align: center
    :height: 100px
    :alt: graphql-java-logo


Our documentation moved: please go to `https://www.graphql-java.com/documentation <https://www.graphql-java.com/documentation>`_
--------------------------------------------------------------------------------------------------------------------------------

